/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import za.ac.tut.model.bl.EmployeeFacadeLocal;
import za.ac.tut.model.entities.Address;
import za.ac.tut.model.entities.Emails;
import za.ac.tut.model.entities.Employee;

/**
 *
 * @author Student
 */
public class AddEmployeeServlet extends HttpServlet 
{
    @EJB
    private EmployeeFacadeLocal efl;
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        HttpSession session = request.getSession();
        List<Emails> theEmails = (List<Emails> )session.getAttribute("theEmails");
        
        Employee employee = getEmployee(theEmails , request);
        
        String msg = "Employee has been successfully added into database";
        
        efl.create(employee);
        
        request.setAttribute("msg", msg);
        
        RequestDispatcher rd = request.getRequestDispatcher("outcome.jsp");
        rd.forward(request, response);
        
    }

    private Employee getEmployee(List<Emails> theEmails, HttpServletRequest request) 
    {
        Long idNumber = Long.valueOf(request.getParameter("idNumber"));
        String name = request.getParameter("name");
        
        String street = request.getParameter("street");
        Address address = new Address(street);
        
        return new Employee(idNumber, name, address, theEmails);
    }
}
