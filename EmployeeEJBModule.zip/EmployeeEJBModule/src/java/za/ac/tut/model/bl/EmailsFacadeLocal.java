/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.model.bl;

import java.util.List;
import javax.ejb.Local;
import za.ac.tut.model.entities.Emails;

/**
 *
 * @author Student
 */
@Local
public interface EmailsFacadeLocal {

    void create(Emails emails);

    void edit(Emails emails);

    void remove(Emails emails);

    Emails find(Object id);

    List<Emails> findAll();

    List<Emails> findRange(int[] range);

    int count();
    
}
